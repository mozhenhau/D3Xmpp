package org.jivesoftware.openfire.plugin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jivesoftware.database.DbConnectionManager;

/**
 * 
 * MUC��Ϣ��ȡ��
 * 
 * @author MZH
 * 
 */
public class MUCDao {
	/*
	 * �����û�Jid��ѯ�û����ڵ����з�����Ϣ
	 */
	public static List<Map<String, String>> getMUCInfo(String jid) {

		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		String sql = "select ofMucRoom.serviceID, ofMucRoom.name, ofMucRoom.roomid ,ofMucMember.nickname from "
				+ "ofMucRoom join ofMucMember on ofMucRoom.roomID = ofMucMember.roomID and ofMucMember.jid = ?";
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		Map<String, String> map = null;
		try {
			connection = DbConnectionManager.getConnection();
			statement = connection.prepareStatement(sql);
			statement.setString(1, jid);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				map = new HashMap<String, String>();
				map.put("serviceID", resultSet.getString(1));
				map.put("name", resultSet.getString(2));
				map.put("roomid", resultSet.getString(3));
				map.put("nickname", resultSet.getString(4));
				list.add(map);
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		} finally {
			DbConnectionManager.closeConnection(resultSet, statement,
					connection);
		}
		return list;
	}
	
	/*
	 * ���ݷ���id��ȡ���������к��ѵ���Ϣ
	 */
	public static List<Map<String, String>> getRoomeInfo(String roomid) {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		String sql = "select jid, nickname from ofMucMember where roomID = ?";
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		Map<String, String> map = null;
		try {
			connection = DbConnectionManager.getConnection();
			statement = connection.prepareStatement(sql);
			statement.setString(1, roomid);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				map = new HashMap<String, String>();
				map.put("jid", resultSet.getString(1));
				map.put("nickname", resultSet.getString(2));
				list.add(map);
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		} finally {
			DbConnectionManager.closeConnection(resultSet, statement,
					connection);
		}
		return list;
	}
}
