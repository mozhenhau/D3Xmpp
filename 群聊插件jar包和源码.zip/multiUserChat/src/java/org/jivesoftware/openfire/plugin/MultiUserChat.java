package org.jivesoftware.openfire.plugin;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Namespace;
import org.jivesoftware.database.DbConnectionManager;
import org.jivesoftware.openfire.IQRouter;
import org.jivesoftware.openfire.XMPPServer;
import org.jivesoftware.openfire.container.Plugin;
import org.jivesoftware.openfire.container.PluginManager;
import org.jivesoftware.openfire.event.SessionEventDispatcher;
import org.jivesoftware.openfire.event.SessionEventListener;
import org.jivesoftware.openfire.muc.MUCEventDispatcher;
import org.jivesoftware.openfire.muc.MUCEventListener;
import org.jivesoftware.openfire.muc.MUCRoom;
import org.jivesoftware.openfire.muc.spi.LocalMUCRoom;
import org.jivesoftware.openfire.muc.spi.MultiUserChatServiceImpl;
import org.jivesoftware.openfire.session.Session;
import org.jivesoftware.openfire.vcard.VCardManager;
import org.jivesoftware.util.Log;
import org.xmpp.packet.IQ;
import org.xmpp.packet.JID;
import org.xmpp.packet.Message;

/**
 * 
 * ʵ�����÷��䣬�ҵ��û���¼ʱʵ����QQһ���Զ����뷿��
 * 
 * @author MZH
 * 
 */
public class MultiUserChat implements SessionEventListener, MUCEventListener,
		Plugin {

	private static final String ADD_MEMBER = "INSERT INTO ofMucMember (roomID,jid,nickname) VALUES (?,?,?)";
	private static final String SELECT_MEMBER = "SELECT * FROM ofMucMember WHERE jid = ? and roomID = ?";
	private XMPPServer server;
	private MultiUserChatServiceImpl mucService;
	private IQRouter router;

	@Override
	public void initializePlugin(PluginManager manager, File pluginDirectory) {
		// TODO Auto-generated method stub
		server = XMPPServer.getInstance();
		MUCEventDispatcher.addListener(this);
		SessionEventDispatcher.addListener(this);

		router = XMPPServer.getInstance().getIQRouter();
	}

	@Override
	public void destroyPlugin() {
		// TODO Auto-generated method stub
		MUCEventDispatcher.removeListener(this);
		server = null;
	}

	@Override
	public void roomCreated(final JID roomJID) {
		// TODO Auto-generated method stub
//		System.out.println("room createeeeeeeeeeeeeeeeeeeeeeeeeeeeee:"+roomJID+"-----"+mucRoom.getID());
		new Thread(){
			public void run() {
				try {
					sleep(1*1000);
					MUCRoom mucRoom = server.getMultiUserChatManager()
							.getMultiUserChatService(roomJID)
							.getChatRoom(roomJID.getNode());
					server.getMultiUserChatManager().getMultiUserChatService(roomJID).refreshChatRoom(mucRoom.getName());
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			};
		}.start();
	}

	@Override
	public void roomDestroyed(JID roomJID) {
		System.out.println("room destoryyyyyyyyyyyyyyyyyyyyyyyyyyyyy:");
	}

	@Override
	public void occupantJoined(final JID roomJID, final JID user, final String nickname) {
		new Thread(){
			public void run() {
				try {
					sleep(2*1000);
					MUCRoom mucRoom = server.getMultiUserChatManager()
							.getMultiUserChatService(roomJID)
							.getChatRoom(roomJID.getNode());
					// �Ƿ������÷���
					if (mucRoom.isPersistent()) {
						// ��ǰ�û��Ƿ��Ѿ�����
						System.out.println("saveeeee::"+user.toString()+"  id:"+mucRoom.getID());
						if (!userExist(mucRoom.getID(),user)) {
							saveMember(mucRoom, user, user.getNode());
//							joinRooms(user);
						}
						System.out.println("It is a persistent room: RoomJid:"
								+ roomJID.toString() + ";UserJID:"
								+ user.toString() + ";nickname:" + nickname);
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			};
		}.start();
	}

	@Override
	public void occupantLeft(JID roomJID, JID user) {
		System.out.println("left!!!!!!!!!!!!!!!!!!!!!!!!"+roomJID.toBareJID());
	}

	@Override
	public void nicknameChanged(JID roomJID, JID user, String oldNickname,
			String newNickname) {
		// TODO Auto-generated method stub

	}

	@Override
	public void messageReceived(JID roomJID, JID user, String nickname,
			Message message) {
		// TODO Auto-generated method stub

	}

	@Override
	public void privateMessageRecieved(JID toJID, JID fromJID, Message message) {
		// TODO Auto-generated method stub

	}

	@Override
	public void roomSubjectChanged(JID roomJID, JID user, String newSubject) {
		// TODO Auto-generated method stub

	}

	/*
	 * ���Ҹ�����JID�û��Ƿ����
	 */
	public static boolean userExist(long roomId,JID bareJID) {
		boolean sign = false;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet resultSet = null;
		try {
			con = DbConnectionManager.getConnection();
			pstmt = con.prepareStatement(SELECT_MEMBER);
			pstmt.setString(1, bareJID.toBareJID());
			pstmt.setLong(2, roomId);
			resultSet = pstmt.executeQuery();
			if (resultSet.next()) {
				sign = true;
			}
		} catch (SQLException sqle) {
			Log.error(sqle.getMessage(), sqle);
		} finally {
			DbConnectionManager.closeConnection(pstmt, con);
		}
		return sign;
	}

	/*
	 * �����뷿����û����л������ݿ���
	 */
	@SuppressWarnings("deprecation")
	public static void saveMember(MUCRoom mucRoom, JID bareJID, String resource) {
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = DbConnectionManager.getConnection();
			pstmt = con.prepareStatement(ADD_MEMBER);
			pstmt.setLong(1, mucRoom.getID());
			pstmt.setString(2, bareJID.toBareJID());
			pstmt.setString(3, resource);
			pstmt.executeUpdate();
		} catch (SQLException sqle) {
			Log.error(sqle.getMessage(), sqle);
		} finally {
			DbConnectionManager.closeConnection(pstmt, con);
		}
	}
	
	@Override
	public void sessionCreated(Session session) {
		// TODO Auto-generated method stub
		JID userJid = session.getAddress();
		
		joinRooms(userJid);
	}

	@Override
	public void sessionDestroyed(Session session) {
		// TODO Auto-generated method stub
		JID userJid =session.getAddress();
		//���߸ı�����
		Element vcardElem = VCardManager.getInstance().getVCard(userJid.getNode());
		if (vcardElem!=null) {
			Element adrElem = vcardElem.element("latAndlon");
			vcardElem.remove(adrElem);
			adrElem.setText(4.9E-324+","+4.9E-324);
			vcardElem.add(adrElem);
			try {
				VCardManager.getInstance().setVCard(userJid.getNode(), vcardElem);
			} catch (Exception e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
		}
	}

	@Override
	public void anonymousSessionCreated(Session session) {
		// TODO Auto-generated method stub

	}

	@Override
	public void anonymousSessionDestroyed(Session session) {
		// TODO Auto-generated method stub

	}

	@Override
	public void resourceBound(Session session) {
		// TODO Auto-generated method stub

	}

	/*
	 * �û���¼��ͻ���뷿�� 
	 * <iq type="result" to="ycl5@192.168.27.39/Spark 2.6.3" id="MZH"> 
	 * <muc xmlns="MZH"> 
	 * <room xmlns="" account="ycl5@192.168.27.39/Spark 2.6.3">222@conference.192.168.27.39</room>
	 * </muc></iq>
	 */
	public void joinRooms(JID userJid) {
		List<Map<String, String>> dataofRoom = MUCDao.getMUCInfo(userJid.toBareJID());

		if (dataofRoom == null || dataofRoom.isEmpty()) {
			return;
		}
		Map<String, String> mapofRoom = null;

		/**
		 * ����iq����չ�������ڷ����û����ڷ�������ơ�
		 */
		Document document = DocumentHelper.createDocument();
		Element iqe = document.addElement("iq");
		iqe.addAttribute("type", "result");
		iqe.addAttribute("to", userJid.toFullJID());
		iqe.addAttribute("id", "MZH");

		Namespace namespace = new Namespace("", "MZH");
		Element muc = iqe.addElement("muc");
		muc.add(namespace);

		for (int i = 0, len = dataofRoom.size(); i < len; i++) {
			mapofRoom = dataofRoom.get(i);

			String serviceID = mapofRoom.get("serviceID");
			mucService = (MultiUserChatServiceImpl) server
					.getMultiUserChatManager().getMultiUserChatService(
							Long.parseLong(serviceID));
			String roomName = mapofRoom.get("name");
			LocalMUCRoom room = (LocalMUCRoom) mucService.getChatRoom(roomName);

			// ����room��,roomname,account��Ϣ
			Element roome = muc.addElement("room");
			// roome.setText(room.getJID().toBareJID());
			roome.addAttribute("roomJid", room.getID()+"");
			roome.addAttribute("roomName", room.getName());
			roome.addAttribute("account", userJid.toFullJID());
			
			List<Map<String, String>> dataofRoome = MUCDao.getRoomeInfo(mapofRoom.get("roomid"));

			if (dataofRoome == null || dataofRoome.isEmpty()) {
				return;
			}
			Map<String, String> mapofRoome = null;
			for (int j = 0; j < dataofRoome.size(); j++) {
				
				mapofRoome = dataofRoome.get(j);
				String jid = mapofRoome.get("jid");
				String nickname = mapofRoome.get("nickname");
				
				//��room�ڵ�������roome��Ϣ
				Element roomee = roome.addElement("friend");
				roomee.setText(jid);
			}
		}
		// ����ͳ�ȥ��
		IQ iq = new IQ(iqe);
		System.out.println("roommmmmmmmmmm iq " + iq.toXML());
		router.route(iq);
	}
//	
//	public static void refreshCache(long roomId){
//		List<MultiUserChatService> list = XMPPServer.getInstance().getMultiUserChatManager().getMultiUserChatServices();
//		for (MultiUserChatService service:list) {
//			List<MUCRoom> mucRooms =  service.getChatRooms();
//			for (MUCRoom mucRoom :mucRooms) {
//				long rId = mucRoom.getID();
//				if(rId == roomId){
//					JID roomJID = mucRoom.getJID();
//					String roomName = mucRoom.getName();
//					XMPPServer.getInstance().getMultiUserChatManager().getMultiUserChatService(roomJID).refreshChatRoom(roomName);
//					Log.info("service.getServiceDomain() ��������ɹ�:"+service.getServiceDomain());
//				}
//			}
//			
//		}
//	}
//	
}
